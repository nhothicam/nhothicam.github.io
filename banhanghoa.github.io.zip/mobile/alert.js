function a(){
if(window.innerWidth <= 800 && window.innerHeight <= 600) { alert("<"); } else { alert(""); }
}
